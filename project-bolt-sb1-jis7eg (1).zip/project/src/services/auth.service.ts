import { Auth } from 'aws-amplify';
import { User } from '../types';

export const authService = {
  async login(email: string, password: string): Promise<User> {
    try {
      const user = await Auth.signIn(email, password);
      return {
        id: user.attributes.sub,
        email: user.attributes.email,
        name: user.attributes.name,
      };
    } catch (error) {
      throw new Error('Login failed');
    }
  },

  async signup(email: string, password: string, name: string): Promise<User> {
    try {
      await Auth.signUp({
        username: email,
        password,
        attributes: {
          email,
          name,
        },
      });
      
      return this.login(email, password);
    } catch (error) {
      throw new Error('Signup failed');
    }
  },

  async logout(): Promise<void> {
    try {
      await Auth.signOut();
    } catch (error) {
      throw new Error('Logout failed');
    }
  },

  async getCurrentUser(): Promise<User | null> {
    try {
      const user = await Auth.currentAuthenticatedUser();
      return {
        id: user.attributes.sub,
        email: user.attributes.email,
        name: user.attributes.name,
      };
    } catch {
      return null;
    }
  },
};