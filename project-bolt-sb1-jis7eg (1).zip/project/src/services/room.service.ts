import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, QueryCommand, PutCommand } from '@aws-sdk/lib-dynamodb';
import { Room, Booking } from '../types';
import { awsConfig } from '../config/aws-config';

const client = new DynamoDBClient(awsConfig);
const docClient = DynamoDBDocumentClient.from(client);

export const roomService = {
  async getRooms(): Promise<Room[]> {
    const command = new QueryCommand({
      TableName: 'Rooms',
      IndexName: 'StatusIndex',
      KeyConditionExpression: '#status = :status',
      ExpressionAttributeNames: {
        '#status': 'status',
      },
      ExpressionAttributeValues: {
        ':status': 'available',
      },
    });

    try {
      const response = await docClient.send(command);
      return response.Items as Room[];
    } catch (error) {
      throw new Error('Failed to fetch rooms');
    }
  },

  async bookRoom(booking: Omit<Booking, 'id'>): Promise<Booking> {
    const bookingId = crypto.randomUUID();
    const command = new PutCommand({
      TableName: 'Bookings',
      Item: {
        id: bookingId,
        ...booking,
        createdAt: new Date().toISOString(),
        status: 'confirmed',
      },
    });

    try {
      await docClient.send(command);
      return { id: bookingId, ...booking };
    } catch (error) {
      throw new Error('Failed to book room');
    }
  },
};