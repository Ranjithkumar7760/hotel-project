import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Calendar, Clock } from 'lucide-react';
import { format } from 'date-fns';

export const BookingConfirmation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const booking = location.state?.booking;

  if (!booking) {
    return (
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900">Booking not found</h2>
        <button
          onClick={() => navigate('/rooms')}
          className="mt-4 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
        >
          Return to Rooms
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900">Booking Confirmed!</h2>
        <p className="mt-2 text-gray-600">Your reservation has been successfully booked.</p>
      </div>

      <div className="space-y-6">
        <div className="border-t border-b border-gray-200 py-6">
          <h3 className="text-lg font-semibold mb-4">Booking Details</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center">
              <Calendar className="h-5 w-5 text-blue-600 mr-2" />
              <div>
                <p className="text-sm text-gray-500">Check-in</p>
                <p className="font-medium">{format(new Date(booking.checkIn), 'PPP')}</p>
              </div>
            </div>
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-blue-600 mr-2" />
              <div>
                <p className="text-sm text-gray-500">Check-out</p>
                <p className="font-medium">{format(new Date(booking.checkOut), 'PPP')}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-b border-gray-200 pb-6">
          <h3 className="text-lg font-semibold mb-4">Payment Summary</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Room Rate</span>
              <span className="font-medium">${booking.totalPrice}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Taxes & Fees</span>
              <span className="font-medium">${Math.round(booking.totalPrice * 0.1)}</span>
            </div>
            <div className="flex justify-between pt-4 border-t border-gray-200">
              <span className="font-semibold">Total</span>
              <span className="font-bold text-blue-600">
                ${Math.round(booking.totalPrice * 1.1)}
              </span>
            </div>
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={() => navigate('/rooms')}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            Book Another Room
          </button>
        </div>
      </div>
    </div>
  );
};