import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Wifi, Coffee, Tv, Users } from 'lucide-react';
import { Room } from '../types';

const rooms: Room[] = [
  {
    id: '1',
    type: 'Deluxe',
    name: 'Deluxe Ocean View',
    price: 299,
    description: 'Luxurious room with stunning ocean views and premium amenities.',
    imageUrl: 'https://images.unsplash.com/photo-1611892440504-42a792e24d32?auto=format&fit=crop&q=80&w=2070',
    amenities: ['Ocean View', 'King Bed', 'Wi-Fi', 'Mini Bar'],
    maxOccupancy: 2
  },
  {
    id: '2',
    type: 'Suite',
    name: 'Executive Suite',
    price: 499,
    description: 'Spacious suite with separate living area and premium services.',
    imageUrl: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&q=80&w=2070',
    amenities: ['City View', 'King Bed', 'Living Room', 'Butler Service'],
    maxOccupancy: 3
  },
  {
    id: '3',
    type: 'Standard',
    name: 'Classic Room',
    price: 199,
    description: 'Comfortable room with modern amenities and city views.',
    imageUrl: 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?auto=format&fit=crop&q=80&w=2070',
    amenities: ['City View', 'Queen Bed', 'Wi-Fi', 'Work Desk'],
    maxOccupancy: 2
  }
];

export const RoomList: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-gray-900">Available Rooms</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {rooms.map((room) => (
          <div key={room.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={room.imageUrl}
              alt={room.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">{room.name}</h3>
                  <p className="text-sm text-gray-500">{room.type}</p>
                </div>
                <p className="text-2xl font-bold text-blue-600">${room.price}</p>
              </div>
              <p className="mt-4 text-gray-600">{room.description}</p>
              <div className="mt-4 flex items-center space-x-4">
                <div className="flex items-center text-gray-500">
                  <Wifi className="h-4 w-4 mr-1" />
                  <span className="text-sm">Wi-Fi</span>
                </div>
                <div className="flex items-center text-gray-500">
                  <Coffee className="h-4 w-4 mr-1" />
                  <span className="text-sm">Mini Bar</span>
                </div>
                <div className="flex items-center text-gray-500">
                  <Tv className="h-4 w-4 mr-1" />
                  <span className="text-sm">TV</span>
                </div>
                <div className="flex items-center text-gray-500">
                  <Users className="h-4 w-4 mr-1" />
                  <span className="text-sm">Max {room.maxOccupancy}</span>
                </div>
              </div>
              <button
                onClick={() => navigate(`/book/${room.id}`)}
                className="mt-6 w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
              >
                Book Now
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};