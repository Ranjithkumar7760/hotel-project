import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { roomService } from '../services/room.service';
import { paymentService } from '../services/payment.service';
import { Booking } from '../types';
import toast from 'react-hot-toast';

export const useBooking = () => {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const bookRoom = async (bookingData: Omit<Booking, 'id'>) => {
    setLoading(true);
    try {
      const sessionId = await paymentService.createPaymentSession({
        roomId: bookingData.roomId,
        totalPrice: bookingData.totalPrice,
        checkIn: bookingData.checkIn,
        checkOut: bookingData.checkOut,
      });

      const booking = await roomService.bookRoom(bookingData);
      
      navigate('/booking-confirmation', { state: { booking } });
      toast.success('Room booked successfully!');
    } catch (error) {
      toast.error('Booking failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return { bookRoom, loading };
};