import { differenceInDays, format, isAfter, isBefore, startOfDay } from 'date-fns';

export const calculateNights = (checkIn: Date, checkOut: Date): number => {
  return differenceInDays(checkOut, checkIn);
};

export const calculateTotalPrice = (pricePerNight: number, nights: number): number => {
  return pricePerNight * nights;
};

export const isValidDateRange = (checkIn: Date, checkOut: Date): boolean => {
  const today = startOfDay(new Date());
  return (
    isAfter(checkIn, today) &&
    isAfter(checkOut, checkIn) &&
    differenceInDays(checkOut, checkIn) > 0
  );
};