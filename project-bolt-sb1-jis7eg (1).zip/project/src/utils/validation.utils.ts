import { z } from 'zod';

export const bookingSchema = z.object({
  checkIn: z.date(),
  checkOut: z.date(),
  roomId: z.string(),
  userId: z.string(),
  totalPrice: z.number().positive(),
});

export const userSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2),
});