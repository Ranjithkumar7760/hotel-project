import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Wifi, Coffee, Tv, Users } from 'lucide-react';
import { Room } from '../../types';

interface RoomCardProps {
  room: Room;
}

export const RoomCard: React.FC<RoomCardProps> = ({ room }) => {
  const navigate = useNavigate();

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <img
        src={room.imageUrl}
        alt={room.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-xl font-semibold text-gray-900">{room.name}</h3>
            <p className="text-sm text-gray-500">{room.type}</p>
          </div>
          <p className="text-2xl font-bold text-blue-600">${room.price}</p>
        </div>
        <p className="mt-4 text-gray-600">{room.description}</p>
        <div className="mt-4 flex items-center space-x-4">
          <div className="flex items-center text-gray-500">
            <Wifi className="h-4 w-4 mr-1" />
            <span className="text-sm">Wi-Fi</span>
          </div>
          <div className="flex items-center text-gray-500">
            <Coffee className="h-4 w-4 mr-1" />
            <span className="text-sm">Mini Bar</span>
          </div>
          <div className="flex items-center text-gray-500">
            <Tv className="h-4 w-4 mr-1" />
            <span className="text-sm">TV</span>
          </div>
          <div className="flex items-center text-gray-500">
            <Users className="h-4 w-4 mr-1" />
            <span className="text-sm">Max {room.maxOccupancy}</span>
          </div>
        </div>
        <button
          onClick={() => navigate(`/book/${room.id}`)}
          className="mt-6 w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
        >
          Book Now
        </button>
      </div>
    </div>
  );
};