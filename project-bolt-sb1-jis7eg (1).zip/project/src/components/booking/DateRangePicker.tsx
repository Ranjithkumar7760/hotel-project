import React from 'react';
import { format } from 'date-fns';

interface DateRangePickerProps {
  checkIn: Date;
  checkOut: Date;
  onCheckInChange: (date: Date) => void;
  onCheckOutChange: (date: Date) => void;
}

export const DateRangePicker: React.FC<DateRangePickerProps> = ({
  checkIn,
  checkOut,
  onCheckInChange,
  onCheckOutChange,
}) => {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div>
        <label className="block text-sm font-medium text-gray-700">Check-in Date</label>
        <input
          type="date"
          value={format(checkIn, 'yyyy-MM-dd')}
          min={format(new Date(), 'yyyy-MM-dd')}
          onChange={(e) => onCheckInChange(new Date(e.target.value))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700">Check-out Date</label>
        <input
          type="date"
          value={format(checkOut, 'yyyy-MM-dd')}
          min={format(checkIn, 'yyyy-MM-dd')}
          onChange={(e) => onCheckOutChange(new Date(e.target.value))}
          className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        />
      </div>
    </div>
  );
};