export interface User {
  id: string;
  email: string;
  name: string;
}

export interface Room {
  id: string;
  type: string;
  name: string;
  price: number;
  description: string;
  imageUrl: string;
  amenities: string[];
  maxOccupancy: number;
}

export interface Booking {
  id: string;
  userId: string;
  roomId: string;
  checkIn: Date;
  checkOut: Date;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'cancelled';
}